import csv
import random

WORDSLIST = 'english-words.csv' #500 words, each line started with id number

def getRandomWord():
    with open(WORDSLIST, 'r') as f:
        csvreader = csv.DictReader(f, delimiter=";")
        rndm = random.randint(1,501)
        row = filter(lambda x: str(rndm) == x["id"], csvreader)
        for i in row:
            result = i["word"]
            
        return result
    

def play():
    word = getRandomWord()
    #print(word)
    wordlen = len(word)
    testString = list(wordlen * "_")
    
    prompt='> '
    incorr_inpt = -1
    while incorr_inpt <= 0 or incorr_inpt > wordlen:
        print(f"How many incorrect attempts for the game you'd like to set? Not more than {wordlen} ")
        incorr_inpt = int(input(prompt))
    
    curr_inpt = 0

    while curr_inpt <= (incorr_inpt):
        print(" ".join(testString))
        letter = input("Give me some letter: ")
        while len(letter)>1 or letter.isdigit():
            letter = input("Give me some LETTER. Can't give more than one char, neither digit: ")
        letter = letter.lower()
        if letter in word:
            print("Good shoot!")
            occurences  = [i for i, char in enumerate(word) if char == letter]
            for i in occurences:
                testString[i] = letter
                if "_" not in testString:
                    print("You won! Congrats :)")
                    exit()
        else:
            curr_inpt += 1
            leftover = incorr_inpt - curr_inpt
            if leftover >= 0:
                print("try again! leftover moves: ", leftover )
            else:
                print("You lost, end of the game! the word was: ", word)
                


play()

    


